#if ($HEADER_COMMENTS)
/// =======================================
/// Created by $USER_NAME on ${MONTH_NAME_SHORT} ${DAY}, ${YEAR}
/// =======================================
#if ($ORGANIZATION_NAME && $ORGANIZATION_NAME != "")
// Copyright (c) $YEAR ${ORGANIZATION_NAME}#if (!$ORGANIZATION_NAME.endsWith(".")).#end All rights reserved.
#end
//
#end