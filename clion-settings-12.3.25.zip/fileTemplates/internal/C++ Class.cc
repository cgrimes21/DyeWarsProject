#parse("CustomHeader.h")
#[[#include]]# "${HEADER_FILENAME}"

${NAMESPACES_OPEN_CPP}
${NAMESPACES_CLOSE_CPP}