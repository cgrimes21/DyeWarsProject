#parse("CustomHeader.h")
#pragma once
${NAMESPACES_OPEN}

class ${NAME} {
public:

private:

};

${NAMESPACES_CLOSE}
